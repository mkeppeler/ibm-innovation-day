/*
 * IBM Confidential
 * © Copyright IBM Corp. 2025
 */
'use strict';

function authenticate(pid, authKey) {
	const configCache = require('@sdk/config_cache')(pid);

	return new Promise((resolve, reject) => {
		const cachedConfig = configCache.retrieve(authKey, ['T-Systems/USP']);
		if (cachedConfig) {
			resolve();
			return;
		}

		configCache
			.getAuthData(authKey, ['T-Systems/USP'])
			.then(auth => {
				if (!auth) {
					reject('authKey not provided.');
				}
				if (!auth.data) {
					reject('Invalid T-Systems authentication credentials!!!');
				} else {
					configCache.register(authKey, auth.data);
					resolve();
				}
			})
			.catch(reject);
	});
}

module.exports = authenticate;
