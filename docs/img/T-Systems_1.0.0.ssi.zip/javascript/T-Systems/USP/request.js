/*
 * IBM Confidential
 * © Copyright IBM Corp. 2025
 */
'use strict';
const authenticate = require('./authenticate');
const axios = require('axios');
const https = require('https');
const builder = require('xml2js').Builder;
const parseString = require('xml2js').parseString;

function authenticated_request(auth, method, host, path, query, headers, body, formData) {
	if (!body) {
		throw new Error('The body cannot be empty');
	}
	if (Object.keys(body).length === 0) {
		throw new Error(`Missing resource name in the body. Valid body is { "tns:${path.split('/').at(-1)}": {...} }`);
	}
	if (auth.host) {
		host = auth.host;
	}
	if (auth.protocol) {
		host = auth.protocol + host.replace(/^(http[s]?:\/\/)/g, '');
	}
	const uri = host + path;

	// Empty header because of WSDL definition: soapAction=""
	headers['SOAPAction'] = '';
	headers['Content-Type'] = 'text/xml; charset=utf-8';
	headers['Accept'] = 'application/xml';

	const resourceName = Object.keys(body)[0];
	body[resourceName]['auth_user'] = auth.username;
	body[resourceName]['auth_password'] = auth.password;

	const xmlBuilder = new builder();
	body = xmlBuilder.buildObject(body);
	body = body.replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '');
	body = body.replace(`<${resourceName}>`, `<tns:${resourceName}>`);
	body = body.replace(`</${resourceName}>`, `</tns:${resourceName}>`);
	const encBody = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
        <soapenv:Header/>
        <soapenv:Body>
            ${body}
        </soapenv:Body>
    </soapenv:Envelope>`;

	const opts = {
		httpsAgent: new https.Agent({ rejectUnauthorized: false }),
		url: uri,
		method: method,
		headers: headers,
		params: query,
		data: encBody
	};

	opts.transformResponse = function (body) {
		if (body.startsWith('{')) {
			try {
				return JSON.parse(body);
			} catch (e) {
				return body;
			}
		}
		let res = '';
		const options = {
			// options passed to xml2js parser
			trim: false, // trim the leading/trailing whitespace from text nodes
			normalize: false, // trim interior whitespace inside text nodes
			explicitRoot: false, // return the root node in the resulting object?
			emptyTag: null, // the default value for empty nodes
			explicitArray: false, // always put child nodes in an array
			ignoreAttrs: false, // ignore attributes, only create text nodes
			mergeAttrs: false, // merge attributes and child elements
			validator: null // a callable validator
		};
		parseString(body, options, function (err, result) {
			res = result;
		});

		return res || '';
	};

	processRejectUnauthorizedFlag(opts);

	return axios(opts)
		.then(response => {
			return response.data;
		})
		.catch(error => {
			if (error.response?.data) {
				throw error.response.status + ' - ' + JSON.stringify(error.response.data);
			}
			throw error.message;
		});
}

async function promise(userId, authKey, method, host, path, query, headers, body, formData) {
	await authenticate(userId, authKey);
	const configCache = require('@sdk/config_cache')(userId);

	return new Promise((resolve, reject) => {
		const auth = configCache.retrieve(authKey, ['T-Systems/USP']);
		if (!auth) {
			reject('AuthError: Missing authentication configuration');
			return;
		}
		resolve(auth);
	}).then(auth => authenticated_request(auth, method, host, path, query, headers, body, formData));
}

/**
 * Delete rejectUnauthorized if the worker is >= 1.96.0
 */
function processRejectUnauthorizedFlag(opts) {
	if (process.env.VERSION) {
		const version = process.env.VERSION.split('.');
		if (version[0] > 1 || version[1] >= 96) {
			delete opts.httpsAgent;
		}
	}
}

module.exports = promise;
